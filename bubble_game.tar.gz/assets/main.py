import asyncio
import random
import time
import pygame

# =========================
# CONFIG
# =========================
WIDTH, HEIGHT = 1000, 650
FPS = 60

ROUND_SECONDS = 20.0
BUBBLE_LIFETIME = 1.0
BUBBLE_RADIUS = 28

# How many bubbles can appear in a round (we pick a random number each round)
MIN_BUBBLES_PER_ROUND = 18
MAX_BUBBLES_PER_ROUND = 45

# Guess range growth
START_GUESS_RANGE = 5
RANGE_GROWS_EVERY_POINTS = 3   # every N points, range +1
POINTS_PER_EXACT_GUESS = 2

# Bubble spawn timing (we will schedule exactly N spawns in 20s)
MIN_GAP = 0.20  # seconds
MAX_GAP = 0.90  # seconds

# =========================
# COLOURS
# =========================
BG = (16, 20, 28)
PANEL = (22, 28, 40)
TEXT = (235, 240, 255)
MUTED = (160, 170, 190)
ACCENT = (110, 180, 255)
GOOD = (80, 220, 140)
BAD = (240, 90, 90)
BTN = (40, 120, 60)
BTN_TEXT = (15, 25, 18)

# =========================
# HELPERS
# =========================
def clamp(v, lo, hi):
    if v < lo:
        return lo
    if v > hi:
        return hi
    return v

def make_spawn_times(total_bubbles, duration):
    # Create a list of spawn times (seconds from round start) that fit inside duration.
    # We generate random gaps, then scale to fit.
    gaps = [random.uniform(MIN_GAP, MAX_GAP) for _ in range(total_bubbles)]
    s = sum(gaps)
    if s <= 0.0001:
        s = 1.0
    scale = duration / s
    t = 0.0
    times = []
    for g in gaps:
        t += g * scale
        # keep spawns within duration (slightly inside)
        times.append(min(t, duration - 0.02))
    return times

def point_in_circle(mx, my, cx, cy, r):
    dx = mx - cx
    dy = my - cy
    return dx * dx + dy * dy <= r * r

class Bubble:
    def __init__(self, x, y, spawn_t):
        self.x = x
        self.y = y
        self.spawn_t = spawn_t
        self.popped = False

    def alive(self, now):
        return (not self.popped) and (now - self.spawn_t) <= BUBBLE_LIFETIME

    def age(self, now):
        return now - self.spawn_t

    def draw(self, surface, now):
        # Fade as it ages
        a = clamp(1.0 - (self.age(now) / BUBBLE_LIFETIME), 0.0, 1.0)
        # simple fake alpha by scaling colour brightness
        col = (int(ACCENT[0] * (0.55 + 0.45 * a)),
               int(ACCENT[1] * (0.55 + 0.45 * a)),
               int(ACCENT[2] * (0.55 + 0.45 * a)))
        pygame.draw.circle(surface, col, (int(self.x), int(self.y)), BUBBLE_RADIUS)
        pygame.draw.circle(surface, (255, 255, 255), (int(self.x), int(self.y)), BUBBLE_RADIUS, 2)

class Button:
    def __init__(self, rect):
        self.rect = pygame.Rect(rect)

    def draw(self, surf, text, font, fill, tcol):
        pygame.draw.rect(surf, fill, self.rect, border_radius=10)
        pygame.draw.rect(surf, (255,255,255), self.rect, 2, border_radius=10)
        label = font.render(text, True, tcol)
        r = label.get_rect(center=self.rect.center)
        surf.blit(label, r)

    def hit(self, pos):
        return self.rect.collidepoint(pos)

# =========================
# GAME STATE
# =========================
STATE_MENU = "menu"
STATE_GUESS = "guess"
STATE_ROUND = "round"
STATE_RESULT = "result"

async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Bubble Guess Popper")
    clock = pygame.time.Clock()

    font_big = pygame.font.Font(None, 68)
    font = pygame.font.Font(None, 40)
    font_small = pygame.font.Font(None, 30)

    # Buttons
    btn_start = Button((WIDTH//2 - 140, HEIGHT//2 + 70, 280, 60))
    btn_play = Button((WIDTH//2 - 140, HEIGHT//2 + 120, 280, 60))
    btn_again = Button((WIDTH//2 - 140, HEIGHT//2 + 120, 280, 60))

    # Persistent progression
    points = 0
    guess_range = START_GUESS_RANGE

    # Round variables
    state = STATE_MENU
    message = ""
    message_col = TEXT

    total_bubbles_this_round = 0
    planned_spawn_times = []
    round_start_time = 0.0
    spawn_index = 0

    bubbles = []
    popped_count = 0
    guess_value = 0
    guess_min = 0
    guess_max = 0

    # For web: must yield regularly
    running = True

    def recompute_guess_range():
        # range grows by +1 every RANGE_GROWS_EVERY_POINTS points
        nonlocal guess_range
        guess_range = START_GUESS_RANGE + (points // RANGE_GROWS_EVERY_POINTS)

    def start_new_round():
        nonlocal state, message, message_col
        nonlocal total_bubbles_this_round, planned_spawn_times, round_start_time, spawn_index
        nonlocal bubbles, popped_count, guess_value, guess_min, guess_max

        recompute_guess_range()

        bubbles = []
        popped_count = 0
        spawn_index = 0

        total_bubbles_this_round = random.randint(MIN_BUBBLES_PER_ROUND, MAX_BUBBLES_PER_ROUND)
        planned_spawn_times = make_spawn_times(total_bubbles_this_round, ROUND_SECONDS)

        # The player is told how many bubbles will be presented BEFORE guessing.
        # They can guess a value within [total - range, total + range]
        guess_min = max(0, total_bubbles_this_round - guess_range)
        guess_max = total_bubbles_this_round + guess_range

        # Start guess in middle-ish
        guess_value = clamp(total_bubbles_this_round, guess_min, guess_max)

        message = ""
        message_col = TEXT
        state = STATE_GUESS

    def begin_round():
        nonlocal state, round_start_time
        round_start_time = time.perf_counter()
        state = STATE_ROUND

    def finish_round():
        nonlocal state, message, message_col, points
        state = STATE_RESULT

        # Score: exact match only
        if popped_count == guess_value:
            points += POINTS_PER_EXACT_GUESS
            message = f"Exact! +{POINTS_PER_EXACT_GUESS} points"
            message_col = GOOD
        else:
            message = f"Not exact. You guessed {guess_value}, popped {popped_count}"
            message_col = BAD

        recompute_guess_range()

    def draw_header():
        pygame.draw.rect(screen, PANEL, (0, 0, WIDTH, 86))
        title = font.render("Bubble Guess Popper", True, TEXT)
        screen.blit(title, (20, 20))

        ptxt = font.render(f"Points: {points}", True, TEXT)
        screen.blit(ptxt, (WIDTH - 240, 20))

        rtxt = font_small.render(f"Guess range: ±{guess_range}", True, MUTED)
        screen.blit(rtxt, (WIDTH - 240, 56))

    while running:
        now = time.perf_counter()
        dt = clock.tick(FPS) / 1000.0

        # ---- Input ----
        click_pos = None
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                click_pos = pygame.mouse.get_pos()

        # ---- Update ----
        if state == STATE_MENU:
            if click_pos and btn_start.hit(click_pos):
                start_new_round()

        elif state == STATE_GUESS:
            # Click left/right sides to adjust guess (nice for iPad)
            # Or click the Play button.
            if click_pos:
                if btn_play.hit(click_pos):
                    begin_round()
                else:
                    x, y = click_pos
                    # Tap left half: -1, right half: +1 (excluding header area)
                    if y > 100:
                        if x < WIDTH // 2:
                            guess_value = clamp(guess_value - 1, guess_min, guess_max)
                        else:
                            guess_value = clamp(guess_value + 1, guess_min, guess_max)

        elif state == STATE_ROUND:
            elapsed = now - round_start_time

            # spawn bubbles on schedule
            while spawn_index < len(planned_spawn_times) and elapsed >= planned_spawn_times[spawn_index]:
                x = random.randint(60, WIDTH - 60)
                y = random.randint(120, HEIGHT - 60)
                bubbles.append(Bubble(x, y, now))
                spawn_index += 1

            # pop detection
            if click_pos:
                mx, my = click_pos
                for b in bubbles:
                    if b.alive(now) and point_in_circle(mx, my, b.x, b.y, BUBBLE_RADIUS):
                        b.popped = True
                        popped_count += 1
                        break

            # remove dead bubbles
            bubbles = [b for b in bubbles if b.alive(now)]

            # end of round
            if elapsed >= ROUND_SECONDS:
                finish_round()

        elif state == STATE_RESULT:
            if click_pos and btn_again.hit(click_pos):
                start_new_round()

        # ---- Draw ----
        screen.fill(BG)
        draw_header()

        if state == STATE_MENU:
            msg = font_big.render("Ready?", True, TEXT)
            screen.blit(msg, msg.get_rect(center=(WIDTH//2, HEIGHT//2 - 40)))

            sub = font.render("Tap Start to play.", True, MUTED)
            screen.blit(sub, sub.get_rect(center=(WIDTH//2, HEIGHT//2 + 10)))

            btn_start.draw(screen, "Start", font, BTN, BTN_TEXT)

        elif state == STATE_GUESS:
            # Info
            t1 = font.render(f"This round will show: {total_bubbles_this_round} bubbles", True, TEXT)
            screen.blit(t1, t1.get_rect(center=(WIDTH//2, 160)))

            t2 = font.render(f"Your guess (tap left/right to change):", True, MUTED)
            screen.blit(t2, t2.get_rect(center=(WIDTH//2, 215)))

            g = font_big.render(str(guess_value), True, ACCENT)
            screen.blit(g, g.get_rect(center=(WIDTH//2, 290)))

            rng = font_small.render(f"Allowed range: {guess_min} to {guess_max}", True, MUTED)
            screen.blit(rng, rng.get_rect(center=(WIDTH//2, 345)))

            hint = font_small.render("Tip: tap LEFT side to -1, RIGHT side to +1", True, MUTED)
            screen.blit(hint, hint.get_rect(center=(WIDTH//2, HEIGHT - 120)))

            btn_play.draw(screen, "Play 20s round", font, (60, 140, 210), (10, 20, 30))

        elif state == STATE_ROUND:
            # Draw bubbles
            for b in bubbles:
                b.draw(screen, now)

            elapsed = now - round_start_time
            remaining = max(0.0, ROUND_SECONDS - elapsed)

            hud1 = font.render(f"Popped: {popped_count}", True, TEXT)
            screen.blit(hud1, (20, 100))

            hud2 = font.render(f"Guess: {guess_value}", True, MUTED)
            screen.blit(hud2, (20, 140))

            hud3 = font.render(f"Time left: {remaining:0.1f}s", True, TEXT)
            screen.blit(hud3, (WIDTH - 260, 100))

            hud4 = font_small.render(f"Bubbles left to appear: {max(0, total_bubbles_this_round - spawn_index)}", True, MUTED)
            screen.blit(hud4, (WIDTH - 330, 140))

        elif state == STATE_RESULT:
            title = font_big.render("Round Result", True, TEXT)
            screen.blit(title, title.get_rect(center=(WIDTH//2, 170)))

            line1 = font.render(f"You guessed: {guess_value}", True, TEXT)
            screen.blit(line1, line1.get_rect(center=(WIDTH//2, 250)))

            line2 = font.render(f"You popped: {popped_count}", True, TEXT)
            screen.blit(line2, line2.get_rect(center=(WIDTH//2, 300)))

            line3 = font.render(message, True, message_col)
            screen.blit(line3, line3.get_rect(center=(WIDTH//2, 370)))

            line4 = font_small.render(f"New guess range is now ±{guess_range}", True, MUTED)
            screen.blit(line4, line4.get_rect(center=(WIDTH//2, 420)))

            btn_again.draw(screen, "Play again", font, (60, 140, 210), (10, 20, 30))

        pygame.display.flip()

        # Critical for browser: yield to event loop
        await asyncio.sleep(0)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())