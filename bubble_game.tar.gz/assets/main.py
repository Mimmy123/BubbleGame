import asyncio
import random
import time
import math
import pygame

WIDTH, HEIGHT = 1000, 650
FPS = 60
ROUND_SECONDS = 20.0
BUBBLE_LIFETIME = 1.0
BUBBLE_RADIUS = 28

BG = (16, 20, 28)
TEXT = (235, 240, 255)
ACCENT = (110, 180, 255)


class Bubble:
    def __init__(self, x, y, spawn_t):
        self.x = x
        self.y = y
        self.spawn_t = spawn_t
        self.popped = False

    def alive(self, now):
        return (not self.popped) and (now - self.spawn_t) <= BUBBLE_LIFETIME

    def contains(self, mx, my):
        dx = mx - self.x
        dy = my - self.y
        return dx * dx + dy * dy <= BUBBLE_RADIUS * BUBBLE_RADIUS

    def draw(self, surface):
        pygame.draw.circle(surface, ACCENT, (int(self.x), int(self.y)), BUBBLE_RADIUS)
        pygame.draw.circle(surface, (255, 255, 255), (int(self.x), int(self.y)), BUBBLE_RADIUS, 2)


async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    font = pygame.font.Font(None, 40)
    clock = pygame.time.Clock()

    bubbles = []
    popped = 0
    start_time = time.perf_counter()

    running = True

    while running:
        now = time.perf_counter()
        elapsed = now - start_time

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()
                for b in bubbles:
                    if b.contains(mx, my) and not b.popped:
                        b.popped = True
                        popped += 1

        # spawn bubbles randomly
        if random.random() < 0.03:
            x = random.randint(40, WIDTH - 40)
            y = random.randint(40, HEIGHT - 40)
            bubbles.append(Bubble(x, y, now))

        bubbles = [b for b in bubbles if b.alive(now)]

        screen.fill(BG)

        for b in bubbles:
            b.draw(screen)

        text = font.render(f"Popped: {popped}", True, TEXT)
        screen.blit(text, (20, 20))

        pygame.display.flip()
        clock.tick(FPS)

        # THIS LINE PREVENTS BROWSER FREEZE
        await asyncio.sleep(0)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())